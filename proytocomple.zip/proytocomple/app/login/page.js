import React from 'react'
//rafce
const page = () => {
  return (
    <div>Bienvenido a Login</div>
  )
}

export default page