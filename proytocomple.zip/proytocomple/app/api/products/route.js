import product from "@/model/Product";
import connectDB from "@/lib/connectionDB"
import { NextResponse } from "next/server";

export async function GET() {
    await connectDB()
    const products = await product.find()
    return NextResponse.json(JSON.stringify(products))
}
export async function POST(req, res) {
    await connectDB()
    
    const {id, nombre, descripcion, precio, imagen } = await req.json();

    const producto = new product({
       id:id, 
       nombre: nombre, 
       descripcion: descripcion, 
       precio: precio, 
       imagen: imagen
    })
    console.log("DATOS RECIBIDOS EN API",producto , precio)
    await producto.save()
    return NextResponse.json({ message: 'product saved' })
  }
