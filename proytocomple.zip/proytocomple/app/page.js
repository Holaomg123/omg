
'use client';
import { useState, useEffect, Suspense } from 'react';
import Hero from '@/components/Hero'
import Card from '@/components/Card'
import products from '@/mockup/products.json'
export default function Home() {
  //const productos = products
  const [productos, setProductos] = useState([]);
  const [isLoading, setLoading] = useState(true);
  useEffect(
      () => {
          fetch('./api/products', {
              method: 'GET'
          }).then((res) => res.json())
              .then((data) => {
                  setProductos(JSON.parse(data))
                  console.log(JSON.parse(data))
                  setLoading(false)
              })
      }, []
  )
  if (isLoading) return <p>Cargando la página...</p>
  return (
    <main className="mx-auto max-w-6xl p-4">
      <Hero />
      <div>
        <h2 className='font-bold text-2xl text-center m-4'>Productos</h2>
        <div className='grid grid-cols-4 gap-4'>
        <Suspense fallback={<p>Loading feed...</p>}>
            {productos.map((element, index)=>{
              return (<Card key={element.id} dato={element} />)
            })}
            </Suspense>
        </div>
      </div>
    </main>
  );
}
